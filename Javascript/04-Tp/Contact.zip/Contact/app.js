import { Personne } from "./modules/js/Personne";

let creer = () => {
    console.log("bonjour")
}